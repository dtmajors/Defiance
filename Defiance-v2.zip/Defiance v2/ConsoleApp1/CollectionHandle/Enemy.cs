﻿namespace Defiance.CollectionHandle
{
    public class Enemy
    {
        public int ID;
        public string Name;
    }
}