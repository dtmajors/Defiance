﻿namespace Defiance.CollectionHandle
{
    public class Friend
    {
        public int ID;
        public string Name;
    }
}