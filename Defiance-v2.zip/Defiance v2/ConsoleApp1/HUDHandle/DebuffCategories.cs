﻿namespace Defiance.HUDHandle
{
    public enum DebuffCategories
	{
		Life,
	    Creature,
		Item
	}
}
