﻿namespace Defiance.HUDHandle
{
    public class DebuffDisplayInfo
    { 
		public int Icon { get; set; }
		public DebuffDisplayInfo()
		{
			this.Icon = 0;
		}
	}
}
