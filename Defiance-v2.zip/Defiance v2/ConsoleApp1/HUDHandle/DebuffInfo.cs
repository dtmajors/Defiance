﻿namespace Defiance.HUDHandle
{
    public class DebuffInfo
	{
		public int Effect { get; set; }
		public string DisplayName { get; set; }
		public int DefaultDuration { get; set; }
	}
}
