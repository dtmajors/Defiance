﻿using System;

namespace Defiance.HUDHandle
{
	public enum TargetTypes
	{
		Monster,
		Player
	}
}
