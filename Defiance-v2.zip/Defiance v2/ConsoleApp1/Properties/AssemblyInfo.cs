using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Defiance v2")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Defiance v2")]
[assembly: AssemblyCopyright("Copyright ©  2018")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("b06fc7a0-fd06-4c8e-a339-7bf9b1ca2063")]
[assembly: AssemblyVersion("2.0.1.2")]
[assembly: AssemblyFileVersion("2.0.1.2")]